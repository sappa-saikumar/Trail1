package actions;

import org.openqa.selenium.WebElement;
import org.testng.Reporter;

public class Actions {

	public static void element_presence(String Actual, String Expected, String class_methodname) 
	{
		if(condition)
		Reporter.log("Message you wanna print");
		else
			Reporter.log("message you wanna print");
		

	}
	
	
	}
