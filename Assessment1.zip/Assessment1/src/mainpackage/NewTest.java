package mainpackage;

import org.openqa.selenium.Alert;
import org.openqa.selenium.WebDriver;
import org.testng.annotations.Test;

import calling_browser.Browser_Calling;
import pages.Homepageclass;
import pages.Hotelspage;
import pages.Searchhotelspage;
import data.Exceldata;

public class NewTest extends Browser_Calling{
	
	Homepageclass homepageobj;
	Hotelspage hotelspageobj;
	Searchhotelspage searchhotelsobj;
	 
	
@Test
  public void main1() throws Exception 
  {
	homepageobj = new Homepageclass(driver);
	homepageobj.Hotelslink();
  }
	
	
@Test
public void main2() throws Exception{
	hotelspageobj = new Hotelspage(driver);
	hotelspageobj.Enter_location();
	hotelspageobj.Ener_Checkindate();
	hotelspageobj.Enter_Checkoutdate();
	hotelspageobj.searchhotelbutton_Click();
}
	
/*@Test
public void main3() throws Exception
 {
	searchhotelsobj = new Searchhotelspage(driver);
	searchhotelsobj.hoteldetails();

}
*/
}