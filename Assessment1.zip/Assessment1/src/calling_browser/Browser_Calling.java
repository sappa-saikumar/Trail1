package calling_browser;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;

import org.apache.commons.io.FileUtils;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.junit.BeforeClass;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import data.Exceldata;



public class Browser_Calling {
	
	protected WebDriver driver;
	//public Browser_Calling bc;
	

public void load_browser(String returnvalue)
	{
	
		switch(returnvalue)
		{
			case "Chrome":
				System.setProperty("webdriver.chrome.driver","C:\\Users\\483817\\Desktop\\Jars\\chromedriver.exe");
				driver = new ChromeDriver();
				break;
			case "Firefox":
				driver = new FirefoxDriver();
			break;
			
			default:
				System.out.println("Browser is not matched ");
				System.exit(0);
			
				
		}
		
	}
	
	
		
@BeforeTest
	public void  test_trail() throws Exception
	{
		load_browser(Exceldata.load_excel("browsername"));
		driver.manage().window().maximize();
		driver.get("https://www.cleartrip.com/");
		Thread.sleep(3000);
		
		
		
		
	}
	
/*@BeforeMethod
	public void choose_browser() throws Exception
	{
		//load_browser(Exceldata.load_excel("browser"));
		driver.manage().window().maximize();
		driver.get("https://www.cleartrip.com/");
		Thread.sleep(6000);
		
		
	}*/
/*		
@AfterMethod
public void Screenshot() throws Exception
{
	File file = ((TakesScreenshot)driver).getScreenshotAs(OutputType.FILE);
	FileUtils.copyFile(file, new File("C:\\Users\\sappa1\\Desktop\\New folder\\img.jpg"));
	
	
}*/
	
	
@AfterTest
	public void close_browser()
	{
		driver.quit();
	}
		
	
	
	
  
}






