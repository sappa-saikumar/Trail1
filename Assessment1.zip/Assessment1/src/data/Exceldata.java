package data;

import org.testng.annotations.Test;


	

	import java.io.File;
	import java.io.FileInputStream;
	import java.io.FileNotFoundException;
	import java.io.FilterInputStream;
	import java.io.IOException;
import java.sql.Driver;

import org.apache.poi.ss.usermodel.DataFormatter;
import org.apache.poi.xssf.usermodel.XSSFCell;
	import org.apache.poi.xssf.usermodel.XSSFRow;
	import org.apache.poi.xssf.usermodel.XSSFSheet;
	import org.apache.poi.xssf.usermodel.XSSFWorkbook;
	import org.junit.BeforeClass;

	public class Exceldata {

		/*public  String path;*/
		public static FileInputStream file;
		public  static XSSFWorkbook wb;
		public static XSSFSheet sheet;
		public static XSSFRow row;
		public static XSSFCell column;
		public static String content;
		
		public static File path;
		public static String returnvalue;
		//public static 
		
		
		
		public static String load_excel(String objvalue) throws Exception  {
			
			path = new File("C:\\Users\\483817\\Desktop\\Practice\\Assessment1\\Book1.xlsx");
			System.out.println(path.exists());
			file = new FileInputStream(path);
			wb = new XSSFWorkbook(file);
			sheet = wb.getSheetAt(0);
			DataFormatter data = new DataFormatter();			
			
			int columncount = sheet.getRow(0).getPhysicalNumberOfCells();
	
				
			
			for(int i=0;i<columncount;i++)
			{
				int j=0;	
				String actual = data.formatCellValue(sheet.getRow(j).getCell(i));
				if(actual.equalsIgnoreCase(objvalue))
				{
					returnvalue = data.formatCellValue(sheet.getRow(j+1).getCell(i));
					
				}
			}
			wb.close();
			return returnvalue;
			
		}
		
				
				

		
		
		
		
	}
	


