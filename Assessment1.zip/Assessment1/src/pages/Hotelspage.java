package pages;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Scanner;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

import actions.Actions;
import data.Exceldata;

public class Hotelspage {

	protected  WebDriver driver;
	Exceldata exedata;
	 
	
	private By Where_textbox = By.xpath("//*[@id='Tags']");
	private By Checkin_datetextbox = By.xpath("//*[@id='CheckInDate']");
	private By Checkin_dateclick = By.xpath("//*[@id='ui-datepicker-div']/div[@class='monthBlock first']/table/tbody/tr/td/a");
	private By Checkout_datetextbox = By.xpath("//*[@id='CheckOutDate']");
	private By Checkout_dateclick = By.xpath("//*[@id='ui-datepicker-div']/div[@class='monthBlock first']/table/tbody/tr/td/a");
	private By Searchhotelsbutton	= By.id("SearchHotelsButton");
	
	Date date = new Date();
	SimpleDateFormat format = new SimpleDateFormat("yyyy/MM/dd");
	String Modified_date = format.format(date);
	String[] str_checkin = Modified_date.split("/");
	

	
/*	//Clicking check out date
	driver.findElement(Checkout_datetextbox).click();
	System.out.println("Enter check out date");
	Scanner sc = new Scanner(Modified_date);
	
	
	if(str_checkin[2].equals(driver.findElement(Checkout_dateclick).getText()))
	{
		driver.findElement(Checkout_dateclick).click();
	}
	**/

	public Hotelspage(WebDriver driver)
	{
		this.driver = driver;
		
	}
	
	public void Enter_location() throws Exception
	{
		driver.findElement(Where_textbox).sendKeys(Exceldata.load_excel("Place"));
		Thread.sleep(2000);
		
		 driver.findElement(By.xpath("//*[@id='ui-id-1']/li[2]/a")).click();
			
	}
	
	public void Ener_Checkindate()
	{
		WebElement ele =driver.findElement(Checkin_datetextbox);
		Actions.element_presence(ele, "checkindatebox", "Ener_Checkindate");
		
		String name=driver.findElement(Checkin_dateclick).getText();
		name.isEmpty();
		
		if(str_checkin[2].equals(driver.findElement(Checkin_dateclick).getText()))
			driver.findElement(Checkin_dateclick).click();
	}
	
	public void Enter_Checkoutdate() throws Exception
	{
		String[] str_checkout = (Exceldata.load_excel("checkoutdate")).split("-");
		for(String W :str_checkout)
		System.out.println(W);
		driver.findElement(Checkout_datetextbox).click();
		if(str_checkout[2].equals(driver.findElement(Checkout_dateclick).getText()));
		driver.findElement(Checkout_dateclick).click();
		

	}

	public void searchhotelbutton_Click()
	{
		driver.findElement(Searchhotelsbutton).click();
		
	}
}




