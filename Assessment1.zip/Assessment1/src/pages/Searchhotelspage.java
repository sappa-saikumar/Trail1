package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class Searchhotelspage {
	
	protected WebDriver driver;

	public Searchhotelspage(WebDriver driver) {
		this.driver =driver;
	}
	
	
	private By hotelname = By.xpath("//*[@id='378542']/section/nav/ul/li[1]/h2/a");
	
	public void hoteldetails() throws Exception
	{
		Thread.sleep(5000);
		
		String hotelnametext = driver.findElement(hotelname).getText();
		System.out.println(hotelnametext);
	}

}
