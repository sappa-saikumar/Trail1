package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import calling_browser.Browser_Calling;
import data.Exceldata;

public class Homepageclass  {
	
	protected WebDriver driver;
	
	
	private By Hotelslink_path = By.xpath("//*[@id='Home']/div/aside[1]/nav/ul[1]/li[2]/a[1]");
	
	
	public Homepageclass(WebDriver driver) {
		this.driver =driver;
	}


	public void Hotelslink() throws Exception
	{
		driver.findElement(Hotelslink_path).click();
		Thread.sleep(3000);
		
		
			
		
	}
		
	
	

}
